
class AnomalyReport {
    constructor(description, timestep) {
        this.description = description;
        this.timestep = timestep;
    }
}

module.exports = AnomalyReport;